This package will contain the class that displays the console menu and takes the user input.
