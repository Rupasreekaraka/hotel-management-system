package com.vit.hms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.vit.hms.dao.RentalPropertyDAO;
import com.vit.hms.bean.RentalPropertyBean;
import com.vit.hms.util.InvalidCityException;

public class RentalPropertyService {
    
    static RentalPropertyDAO dao= new RentalPropertyDAO();
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String city=null,location=null;
        int bedrooms=0;
        float rentamt=0,minrentamt=0,maxrentamt=0;
        // System.out.println("3. Exit");
        while (true) {
            System.out.println("-------------------------------------");
            System.out.println("1. Add New Rental Property");
            System.out.println("2. Fetch Rental Property");
          switch (sc.nextInt()) {
              case 1: 
              System.out.println("\nEnter new Rental Amount for the Property");
              rentamt=sc.nextFloat();
                System.out.println("\nEnter No. of Bedrooms ");
                bedrooms=sc.nextInt();
                System.out.println("\nEnter the Rental Location");
                location=sc.next();
                System.out.println("\nEnter the Rental City");
                city=sc.next();
                
                RentalPropertyBean newProperty = new RentalPropertyBean();
                newProperty.setcity(city);
                newProperty.setlocation(location);
                newProperty.setrentalAmount(rentamt);
                newProperty.setnoOfBedRooms(bedrooms);
                
                System.out.println( addRentalProperty(newProperty)+"\n");
                break;
                case 2:
                System.out.println("Enter the Conditions for Rental Property\n(minRentalAmount, maxRentalAmount, noOfBedrooms, location and City)");
                System.out.println("\nMinRentalAmount-");
                minrentamt=sc.nextFloat();
                System.out.println("\nMaxRentalAmount-");
                maxrentamt=sc.nextFloat();
                System.out.println("\nNoofBedrooms-");
                bedrooms=sc.nextInt();
                System.out.println("\nLocation-");
                location=sc.next();
                System.out.println("\nCity-");
                city=sc.next();
                
                System.out.println( "\n"+fetchRentalProperty(minrentamt,maxrentamt, bedrooms,location,city)+"\n");

                
                break;
                case 3:
                break;
                default:
                System.out.println("Invalid Choice");
                break;
            }
        }  
        
        

        
        
        

    }

    public static String addRentalProperty(RentalPropertyBean bean){

        int flag=0;

        if(bean.getcity()==null||bean.getlocation()==null)
            return "NULL VALUES IN INPUT";
        if(bean.getcity().length()==0||
            bean.getlocation().length()==0||
            bean.getnoOfBedRooms()==0||
            bean.getRentalAmount()==0)
            return "INVALID INPUT";

        try {
            validateCity(bean.getcity());
            flag=RentalPropertyDAO.createRentalProperty(bean);
            
        } catch (InvalidCityException e) {
            System.out.println(e.toString());
        }

        if(flag==1)
            return "\nSUCCESS";
        else
            return "\nFAILIURE";
        
    }

    
    public static List<RentalPropertyBean> getPropertyByCriteria(float minRentalAmount,
    float maxRentalAmout,int noOfBedRooms,String location,String city) {
        
        RentalPropertyBean bean=new RentalPropertyBean();
        bean.setcity(city);
        bean.setlocation(location);
        bean.setnoOfBedRooms(noOfBedRooms);
        List<RentalPropertyBean> lst= 
        RentalPropertyDAO.findPropertyByCriteria(minRentalAmount,maxRentalAmout,bean);
        return lst;
    }
    
    public static String fetchRentalProperty(
        float minRentalAmount,float maxRentalAmout,int noOfBedRooms,String location,String city) {
            
            List<RentalPropertyBean> lst=new ArrayList<>();
            
            if(minRentalAmount==0||
            maxRentalAmout==0||
            maxRentalAmout<minRentalAmount||
            noOfBedRooms<=0||
            location==null||
            city==null||
            city.length()==0||
            location.length()==0)
            return "INVALID VALUES";
            
            try {
                validateCity(city);
                lst=getPropertyByCriteria(minRentalAmount, maxRentalAmout, noOfBedRooms, location, city);
            } catch (InvalidCityException e) {
                return e.toString();        }
                
                if (lst.isEmpty()) {
                    return "NO MATCHING RECORDS";
        } else {

            System.out.println("PROPERTYID\tRENTALAMOUNT\tBEDROOMS\tLOACTION\tCITY");
            System.out.println("----------------------------------------------------------------------");
            for (RentalPropertyBean b : lst) {
                System.out.print(b.getpropertyId()+"\t\t");
                System.out.print(b.getRentalAmount()+"\t\t");
                System.out.print(b.getnoOfBedRooms()+"\t\t");
                System.out.print(b.getlocation()+"\t");
                System.out.print(b.getcity()+"\t");
                System.out.println("\n");
            }
            return "RECORDS AVAILABLE : "+lst.size();
        }
    }

    public static void validateCity(String city) throws InvalidCityException{
        if (city.equalsIgnoreCase("chennai")||
        city.equalsIgnoreCase("bengaluru")) 
        {
            
        }
        else{
            throw new InvalidCityException("INVALID CITY");
        }
    }
}
